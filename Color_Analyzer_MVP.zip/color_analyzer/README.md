
# Color Analyzer

A Flutter MVP that stores previous Red/Green/Violet results locally and calculates non-guaranteed statistical estimates.

## Features
- Manual result entry
- Local persistence with SharedPreferences
- Historical frequency
- Recent-window weighted estimate
- Basic transition analysis
- Simple historical backtest
- Clear uncertainty/disclaimer messaging

## Run
1. Install Flutter SDK.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.
5. For an APK: `flutter build apk --release`

## Important
This is a statistical analysis tool. It does not guarantee future results and should not be represented as a guaranteed prediction or winning system.
