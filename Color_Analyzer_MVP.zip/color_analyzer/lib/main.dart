
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ColorAnalyzerApp());

enum ColorResult { red, green, violet }

String colorName(ColorResult c) => switch (c) {
  ColorResult.red => 'Red',
  ColorResult.green => 'Green',
  ColorResult.violet => 'Violet',
};

class ResultItem {
  final int round;
  final ColorResult color;
  final DateTime time;

  ResultItem({required this.round, required this.color, required this.time});

  Map<String, dynamic> toJson() => {
    'round': round,
    'color': color.name,
    'time': time.toIso8601String(),
  };

  factory ResultItem.fromJson(Map<String, dynamic> j) => ResultItem(
    round: j['round'],
    color: ColorResult.values.byName(j['color']),
    time: DateTime.parse(j['time']),
  );
}

class ColorAnalyzerApp extends StatelessWidget {
  const ColorAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Color Analyzer',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<ResultItem> results = [];
  int recentWindow = 20;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('results') ?? [];
    setState(() {
      results = raw
          .map((x) => ResultItem.fromJson(jsonDecode(x)))
          .toList()
        ..sort((a, b) => b.round.compareTo(a.round));
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      'results',
      results.map((x) => jsonEncode(x.toJson())).toList(),
    );
  }

  void _add(ColorResult color) {
    final nextRound = results.isEmpty ? 1 : results.map((e) => e.round).reduce(max) + 1;
    setState(() {
      results.insert(0, ResultItem(round: nextRound, color: color, time: DateTime.now()));
    });
    _save();
  }

  void _delete(ResultItem item) {
    setState(() => results.remove(item));
    _save();
  }

  void _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear all results?'),
        content: const Text('This permanently removes the locally stored history.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear')),
        ],
      ),
    );
    if (ok == true) {
      setState(() => results.clear());
      _save();
    }
  }

  Map<ColorResult, int> counts(List<ResultItem> data) {
    return {
      for (final c in ColorResult.values)
        c: data.where((x) => x.color == c).length
    };
  }

  Map<ColorResult, double> estimates() {
    if (results.isEmpty) return {for (final c in ColorResult.values) c: 0};
    final recent = results.take(min(recentWindow, results.length)).toList();
    final all = counts(results);
    final rc = counts(recent);

    // 40% long-run frequency + 60% recent frequency.
    final out = <ColorResult, double>{};
    for (final c in ColorResult.values) {
      final longP = all[c]! / results.length;
      final recentP = rc[c]! / recent.length;
      out[c] = 0.40 * longP + 0.60 * recentP;
    }
    final total = out.values.fold(0.0, (a, b) => a + b);
    if (total > 0) {
      for (final c in ColorResult.values) {
        out[c] = out[c]! / total;
      }
    }
    return out;
  }

  String transitionText() {
    if (results.length < 2) return 'Need at least 2 results.';
    final previous = results[0].color;
    final after = results.skip(1).where((x) => x.color == previous).map((x) {
      final idx = results.indexOf(x);
      return idx > 0 ? results[idx - 1].color : null;
    }).whereType<ColorResult>().toList();
    if (after.isEmpty) return 'No transition data for ${colorName(previous)} yet.';
    final c = counts(after);
    final sorted = c.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return 'After ${colorName(previous)} in this dataset: '
        '${sorted.map((e) => '${colorName(e.key)} ${((e.value / after.length) * 100).round()}%').join(' • ')}';
  }

  Map<String, dynamic> backtest() {
    if (results.length < 20) return {'available': false};
    final chronological = results.reversed.toList();
    int correct = 0, tests = 0;
    for (int i = 10; i < chronological.length; i++) {
      final train = chronological.sublist(0, i);
      final recent = train.take(min(recentWindow, train.length)).toList();
      final all = counts(train);
      final rc = counts(recent);
      ColorResult? best;
      double bestScore = -1;
      for (final c in ColorResult.values) {
        final score = .4 * all[c]! / train.length + .6 * rc[c]! / recent.length;
        if (score > bestScore) { bestScore = score; best = c; }
      }
      if (best == chronological[i].color) correct++;
      tests++;
    }
    return {'available': true, 'correct': correct, 'tests': tests, 'accuracy': tests == 0 ? 0.0 : correct / tests};
  }

  Color uiColor(ColorResult c) => switch (c) {
    ColorResult.red => Colors.red,
    ColorResult.green => Colors.green,
    ColorResult.violet => Colors.deepPurple,
  };

  @override
  Widget build(BuildContext context) {
    final est = estimates();
    final bt = backtest();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Color Analyzer'),
        actions: [IconButton(onPressed: _clear, icon: const Icon(Icons.delete_outline))],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Statistical Estimate', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 6),
                  Text('Historical + recent weighted frequency. Not a guaranteed prediction.',
                      style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 16),
                  ...ColorResult.values.map((c) => _bar(c, est[c] ?? 0)),
                  const SizedBox(height: 10),
                  Text('Data sample: ${results.length} rounds • Recent window: ${min(recentWindow, max(1, results.length))}'),
                ]),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Add result', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  Row(
                    children: ColorResult.values.map((c) => Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: uiColor(c)),
                          onPressed: () => _add(c),
                          child: Text(colorName(c)),
                        ),
                      ),
                    )).toList(),
                  ),
                ]),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Transition analysis', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(transitionText()),
                ]),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Historical backtest', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(bt['available'] == true
                      ? 'Test rounds: ${bt['tests']} • Correct: ${bt['correct']} • Historical accuracy: ${(bt['accuracy'] * 100).toStringAsFixed(1)}%'
                      : 'Need at least 20 stored rounds for a basic backtest.'),
                  const SizedBox(height: 6),
                  const Text('Backtest accuracy describes this historical sample; it does not establish future accuracy.',
                      style: TextStyle(fontSize: 12)),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            Text('Recent results', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            if (results.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No results yet. Add your first result above.')))
            else
              ...results.take(50).map((r) => Card(
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: uiColor(r.color), child: Text(r.round.toString())),
                  title: Text(colorName(r.color)),
                  subtitle: Text(r.time.toLocal().toString().substring(0, 19)),
                  trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => _delete(r)),
                ),
              )),
            const SizedBox(height: 16),
            const Text(
              'Important: This app analyzes historical data only. Random or independent processes may not contain a predictable pattern. Past results do not guarantee future outcomes.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bar(ColorResult c, double p) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(colorName(c), style: const TextStyle(fontWeight: FontWeight.w600)),
          const Spacer(),
          Text('${(p * 100).toStringAsFixed(1)}%'),
        ]),
        const SizedBox(height: 5),
        LinearProgressIndicator(value: p, minHeight: 10),
      ]),
    );
  }
}
